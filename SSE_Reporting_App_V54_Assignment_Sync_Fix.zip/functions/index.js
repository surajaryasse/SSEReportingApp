const { onDocumentWritten } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');
initializeApp();
const db = getFirestore();

// Detect new queue records in appData/main and fan out to registered device tokens.
// A dispatch marker prevents duplicate notifications on Firestore retries.
exports.dispatchSseQueuePush = onDocumentWritten('appData/main', async (event) => {
  const before = event.data?.before?.exists ? (event.data.before.data()?.notifications || []) : [];
  const after = event.data?.after?.exists ? (event.data.after.data()?.notifications || []) : [];
  if (!after.length) return;
  const oldIds = new Set(before.map(x => x && x.id).filter(Boolean));
  const added = after.filter(x => x && x.id && !oldIds.has(x.id));
  for (const item of added.slice(-100)) {
    const marker = db.collection('pushDispatch').doc(String(item.id));
    const markerSnap = await marker.get();
    if (markerSnap.exists) continue;
    // Mark first for idempotency. Failed sends can be inspected in this document.
    await marker.set({ status: 'processing', createdAt: FieldValue.serverTimestamp(), type: item.type || '' });
    try {
      let query = db.collection('pushTokens');
      if (item.toRole && item.toRole !== 'all') query = query.where('role', '==', item.toRole);
      const tokenDocs = await query.get();
      const matched = tokenDocs.docs.filter(d => {
        const t = d.data() || {};
        if (!t.token) return false;
        if (Array.isArray(item.toNames) && item.toNames.length && !item.toNames.includes(t.name)) return false;
        return true;
      });
      const tokens = [...new Set(matched.map(d => d.data().token))];
      if (!tokens.length) { await marker.set({ status: 'no-recipient-token', updatedAt: FieldValue.serverTimestamp() }, { merge: true }); continue; }
      const response = await getMessaging().sendEachForMulticast({
        tokens,
        notification: { title: String(item.title || 'SSE Reporting App').slice(0, 100), body: String(item.body || 'आपके लिए नया अपडेट आया है।').slice(0, 220) },
        data: { eventId: String(item.id), type: String(item.type || ''), url: '/' }
      });
      await marker.set({ status: 'sent', successCount: response.successCount, failureCount: response.failureCount, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      // Remove expired tokens so they do not keep failing.
      const invalid = [];
      response.responses.forEach((r, i) => { if (!r.success && ['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(r.error?.code)) invalid.push(tokens[i]); });
      if (invalid.length) {
        const batch = db.batch();
        matched.filter(d => invalid.includes(d.data().token)).forEach(d => batch.delete(d.ref));
        await batch.commit();
      }
    } catch (error) {
      await marker.set({ status: 'failed', error: String(error.message || error).slice(0, 500), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
      console.error('SSE push dispatch failed', item.id, error);
    }
  }
});
